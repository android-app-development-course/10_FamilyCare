package com.example.manchingma.family_care;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    private Button signup;
    private EditText name;
    private EditText password;
    private EditText psid;
    private EditText phonenumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        signup=(Button)findViewById(R.id.signup_btn);

        name=(EditText)findViewById(R.id.signup_name);
        password=(EditText)findViewById(R.id.signup_password);
        phonenumber=(EditText)findViewById(R.id.signup_number);
        psid=(EditText)findViewById(R.id.signup_pcid);


        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了

                if (name.getText().toString().trim() == null || name.getText().toString().trim().equals("")
                        ||password.getText().toString().trim() == null || password.getText().toString().trim().equals("")
                        ||psid.getText().toString().trim() == null || psid.getText().toString().trim().equals("")
                        ||phonenumber.getText().toString().trim() == null || phonenumber.getText().toString().trim().equals("")) {
                    Toast.makeText(SignupActivity.this, "Sorry, it can't be empty!", Toast.LENGTH_SHORT).show();
                    return;
                }

                else if (name.getText().toString().trim() != null && !(name.getText().toString().trim().equals(""))
                        && password.getText().toString().trim() != null && !(password.getText().toString().trim().equals(""))
                        && phonenumber.getText().toString().trim() != null && !(phonenumber.getText().toString().trim().equals(""))
                        && psid.getText().toString().trim() != null && !(psid.getText().toString().trim().equals(""))
                        )
                {
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}

