package com.example.manchingma.family_care;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.graphics.Color;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {


    // 定位3个Fragment
    private Fragment findFragment = new findFragment();
    private Fragment hostFragment = new hostFragment();
    private Fragment settingsFragment = new settingsFragment();

    // tab中的3个帧布局
    private FrameLayout findFrameLayout, hostFrameLayout,settingsFrameLayout;

    // tab中的3个帧布局中的3个图片组件
    private ImageView findImageView, hostImageView,settingsImageView;

    // tab中的3个帧布局中的3个图片对应文字
    private TextView findTextView, hostTextView, settingsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化组件
        initView();

        // 初始化按钮单击事件
        initClickEvent();

        // 初始化所有fragment
        initFragment();

    }

    /**
     * 初始化所有fragment
     */
    private void initFragment() {


        android.support.v4.app.FragmentTransaction fragmentTransaction =
                getSupportFragmentManager().beginTransaction();

        if (!hostFragment.isAdded()) {
            fragmentTransaction.add(R.id.content, hostFragment);
            fragmentTransaction.hide(hostFragment);
        }
        /*
        if (!settingsFragment.isAdded()) {
            fragmentTransaction.add(R.id.content, settingsFragment);
            fragmentTransaction.hide(settingsFragment);
        }
        if (!findFragment.isAdded()) {
            fragmentTransaction.add(R.id.content, findFragment);
            fragmentTransaction.hide(findFragment);
        }
*/

        hideAllFragment(fragmentTransaction);

        // 默认显示第一个fragment
        fragmentTransaction.show(hostFragment);
        fragmentTransaction.commit();
    }

    /**
     * 隐藏所有fragment
     *
     * @param fragmentTransaction
     */
    private void hideAllFragment(FragmentTransaction fragmentTransaction) {
        fragmentTransaction.hide(hostFragment);
        //fragmentTransaction.hide(settingsFragment);
        //fragmentTransaction.hide(findFragment);
    }


    /**
     * 初始化按钮单击事件
     */
    private void initClickEvent() {
        /*
        findFrameLayout.setOnClickListener((new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.Layout_home:
                        // 点击home tab
                        clickTab(hostFragment);
                        break;

                    case R.id.Layout_settings:
                        // 点击settings tab
                        clickTab(settingsFragment);
                        break;

                    case R.id.Layout_find:
                        // 点击发现tab
                        clickTab(findFragment);
                        break;

                    default:
                        break;
                }
            }
        }));
        */

        hostFrameLayout.setOnClickListener((new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.Layout_home:
                        // 点击home tab
                        clickTab(hostFragment);
                        break;

                    case R.id.Layout_settings:
                        // 点击settings tab
                        clickTab(settingsFragment);
                        break;

                    case R.id.Layout_find:
                        // 点击发现tab
                        clickTab(findFragment);
                        break;

                    default:
                        break;
                }
            }
        }));

/*
        settingsFrameLayout.setOnClickListener((new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.Layout_home:
                        // 点击home tab
                        clickTab(hostFragment);
                        break;

                    case R.id.Layout_settings:
                        // 点击settings tab
                        clickTab(settingsFragment);
                        break;

                    case R.id.Layout_find:
                        // 点击发现tab
                        clickTab(findFragment);
                        break;

                    default:
                        break;
                }
            }
        }));
        */
    }


    /**
     * 初始化组件
     */
    private void initView() {
        //findFrameLayout = (FrameLayout) findViewById(R.id.Layout_find);
        hostFrameLayout = (FrameLayout) findViewById(R.id.Layout_home);
       // settingsFrameLayout = (FrameLayout) findViewById(R.id.Layout_settings);

        //findImageView = (ImageView) findViewById(R.id.findImageView);
        hostImageView = (ImageView) findViewById(R.id.homeImageView);
        //settingsImageView = (ImageView) findViewById(R.id.settingsImageView);

        //findTextView = (TextView) findViewById(R.id.findTextView);
        hostTextView = (TextView) findViewById(R.id.homeTextView);
        //settingsTextView = (TextView) findViewById(R.id.settingsTextView);

    }


    /**
     * 点击下面的Tab按钮
     *
     * @param tabFragment
     */
    private void clickTab(Fragment tabFragment) {

        // 清除上次选中状态
        clearSeleted();

        android.support.v4.app.FragmentTransaction fragmentTransaction =
                getSupportFragmentManager().beginTransaction();


        // 隐藏所有fragment
        hideAllFragment(fragmentTransaction);

        // 显示该Fragment
        fragmentTransaction.show(tabFragment);

        // 提交事务
        fragmentTransaction.commit();

        // 改变tab的样式,设置为选中状态
        changeTabStyle(tabFragment);

    }


    /**
     * 清除上次选中状态
     */
    private void clearSeleted() {
        if (!hostFragment.isHidden()) {
            hostImageView.setImageResource(R.drawable.ic_home_before);
            hostTextView.setTextColor(Color.parseColor("#b7b7b7"));
        }

        /*
        if (!settingsFragment.isHidden()) {
            settingsImageView.setImageResource(R.drawable.ic_settings_before);
            settingsTextView.setTextColor(Color.parseColor("#b7b7b7"));
        }

        if (!findFragment.isHidden()) {
            findImageView.setImageResource(R.drawable.ic_exp_before);
            findTextView.setTextColor(Color.parseColor("#b7b7b7"));
        }
        */
    }


    /**
     * 根据Fragment的状态改变样式
     */
    private void changeTabStyle(Fragment tabFragment) {
        if (tabFragment instanceof hostFragment) {
            hostImageView.setImageResource(R.drawable.ic_host_after);
            hostTextView.setTextColor(Color.parseColor("#2d527c"));
        }

        /*
        if (tabFragment instanceof settingsFragment) {
            settingsImageView.setImageResource(R.drawable.ic_me_after);
            settingsTextView.setTextColor(Color.parseColor("#2d527c"));
        }

        if (tabFragment instanceof findFragment) {
            findImageView.setImageResource(R.drawable.ic_exp_after);
            findTextView.setTextColor(Color.parseColor("#2d527c"));
        }
        */
    }


}
