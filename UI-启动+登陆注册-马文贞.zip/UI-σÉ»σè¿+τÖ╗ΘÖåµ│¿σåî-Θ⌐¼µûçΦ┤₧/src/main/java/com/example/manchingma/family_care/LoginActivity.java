package com.example.manchingma.family_care;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.ActionMenuItemView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private Button login;
    private Button signup;
    private Button forgetpassword;

    private EditText name;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        login=(Button)findViewById(R.id.login);
        signup=(Button)findViewById(R.id.login_signup);
        forgetpassword=(Button)findViewById(R.id.login_forgetpsw);

        name=(EditText)findViewById(R.id.login_account);
        password=(EditText)findViewById(R.id.login_password);

        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了

                if (name.getText().toString().trim() == null || name.getText().toString().trim().equals("")
                        || password.getText().toString().trim() == null || password.getText().toString().trim().equals("")) {
                    Toast.makeText(LoginActivity.this, "Sorry, it can't be empty!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (name.getText().toString().trim() != null && !(name.getText().toString().trim().equals(""))
                        && password.getText().toString().trim() != null && !(password.getText().toString().trim().equals(""))) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        forgetpassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了
                Intent intent = new Intent(LoginActivity.this, forgetpswActivity.class);
                startActivity(intent);
            }
        });
    }
}
