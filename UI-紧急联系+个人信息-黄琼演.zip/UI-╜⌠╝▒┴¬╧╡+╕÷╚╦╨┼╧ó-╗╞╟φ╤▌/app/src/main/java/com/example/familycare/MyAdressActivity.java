package com.example.familycare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyAdressActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_adress);

        ListView my_addressinfo=(ListView)findViewById(R.id.my_adressinfo_item);
        SimpleAdapter mSchedule=new SimpleAdapter(this,
                getMyAdressInfoData(),//数据来源//
                R.layout.my_adressinfo_item,//XML实现
                new String[]{"tile","text"},//数组与ListView对应的子项
                //my_info_item.XML文件里面的两个TextView ID
                new int[]{R.id.ItemTitle,R.id.ItemText} );
        my_addressinfo.setAdapter(mSchedule);
    }
    private List<Map<String,Object>> getMyAdressInfoData(){
        List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
        Map<String,Object>map=new HashMap<String,Object>();
        map.put("title","家");
        map.put("text","你的家庭地址");
        list.add(map);

        return list;
    }
}
