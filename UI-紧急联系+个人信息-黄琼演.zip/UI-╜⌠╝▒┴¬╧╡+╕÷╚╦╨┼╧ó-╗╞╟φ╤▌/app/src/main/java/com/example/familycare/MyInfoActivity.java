package com.example.familycare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info);
        //绑定ListView
        ListView my_info=(ListView)findViewById(R.id.my_info_item);
        SimpleAdapter mSchedule=new SimpleAdapter(this,
                getMyInfoData(),//数据来源//
                R.layout.my_info_item,//XML实现
                new String[]{"ItemTile","ItemText"},//数组与ListView对应的子项
                //my_info_item.XML文件里面的两个TextView ID
                new int[]{R.id.ItemTitle,R.id.ItemText} );
        my_info.setAdapter(mSchedule);

        //my_info.setAdapter(adapter);
    }
    private List<Map<String,Object>> getMyInfoData(){
        List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
         Map<String,Object>map=new HashMap<String,Object>();
        map.put("ItemTitle","昵称");
        map.put("ItemText","你的昵称");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","真实姓名");
        map.put("ItemText","你的真实姓名");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","性别");
        map.put("ItemText","你的性别");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","手机号码");
        map.put("ItemText","你的手机号码");
        list.add(map);

        return list;
    }

}

