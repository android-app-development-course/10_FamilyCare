package com.example.familycare;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        ListView my_addressinfo=(ListView)findViewById(R.id.about_item);
        SimpleAdapter mSchedule=new SimpleAdapter(this,
                getAboutData(),//数据来源//
                R.layout.about_item,//XML实现
                new String[]{"text"},//数组与ListView对应的子项
                //my_info_item.XML文件里面的两个TextView ID
                new int[]{R.id.ItemText} );
        my_addressinfo.setAdapter(mSchedule);
    }
    private List<Map<String,Object>> getAboutData(){
        List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
        Map<String,Object>map=new HashMap<String,Object>();
        map.put("text","功能介绍");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("text","投诉");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("text","查看最新版本");
        list.add(map);
        return list;
    }
}
