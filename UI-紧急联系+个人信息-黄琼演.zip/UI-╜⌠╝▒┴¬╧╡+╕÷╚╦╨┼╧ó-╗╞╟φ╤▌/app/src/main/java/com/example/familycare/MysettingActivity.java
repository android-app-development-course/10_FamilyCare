package com.example.familycare;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MysettingActivity extends Activity {
    private Button my_setting_account;
    private Button my_setting_family;
    private Button my_setting_homeAddress;
    private Button my_setting_setting;
    private Button my_setting_about;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mysetting);
        my_setting_account=(Button)findViewById(R.id.btn_mysetting_account);
        my_setting_family=(Button)findViewById(R.id.btn_mysetting_family);
        my_setting_homeAddress=(Button)findViewById(R.id.btn_mysetting_homeAddress);
        my_setting_setting=(Button)findViewById(R.id.btn_mysetting_setting);
        my_setting_about=(Button)findViewById(R.id.btn_mysetting_help);

        my_setting_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_accont=new Intent(MysettingActivity.this,MyInfoActivity.class);
              //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                startActivity(intent_accont);
            }
        });

        my_setting_family.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_family=new Intent(MysettingActivity.this,MyFamilyInfoActivity.class);
                startActivity(intent_family);
            }
        });

        my_setting_homeAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_adress=new Intent(MysettingActivity.this,MyAdressActivity.class);
                //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                startActivity(intent_adress);
            }
        });

        my_setting_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_setting=new Intent(MysettingActivity.this,settingActivity.class);
                //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                startActivity(intent_setting);
            }
        });
        my_setting_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_about=new Intent(MysettingActivity.this,AboutActivity.class);
                //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                startActivity(intent_about);
            }
        });
    }
}
