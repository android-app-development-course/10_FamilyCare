package com.example.manchingma.family_care.SQLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyHelper extends SQLiteOpenHelper {
    public MyHelper(Context context){
        super(context,"Data.db",null,1);
    }
    public void onCreate(SQLiteDatabase db){
        //db.execSQL("create table mydairy (_id integer primary key autoincrement,title char(20),time char(20),content char(100000))");
        db.execSQL("create table Contact (_id integer primary key autoincrement,name String,number String)");
    }
    public void onUpgrade(SQLiteDatabase db,int oldVersiong,int newVersion){
    }
}