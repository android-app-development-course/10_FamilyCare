package com.example.manchingma.family_care.Settings;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.manchingma.family_care.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FamilyActivity extends Activity {

    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family);

        ListView my_familyinfo=(ListView)findViewById(R.id.my_familyinfo_item);
        SimpleAdapter mSchedule=new SimpleAdapter(this,
                getMyFamilyInfoData(),//数据来源//
                R.layout.family_item,//XML实现
                new String[]{"ItemText"},//数组与ListView对应的子项
                //my_info_item.XML文件里面的两个TextView ID
                new int[]{R.id.ItemText} );
        my_familyinfo.setAdapter(mSchedule);


        back=(Button)findViewById(R.id.toolbar_back_btn);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
    private List<Map<String,Object>> getMyFamilyInfoData(){
        List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
        Map<String,Object>map=new HashMap<String,Object>();
        map.put("ItemText","Father");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemText","Mother");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemText","Daughter");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemText","Son");
        list.add(map);

        return list;
    }
}
