package com.example.manchingma.family_care.SQLite;

/**
 * Created by manchingma on 2018/1/5.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MyOpenHelper extends SQLiteOpenHelper {

    public MyOpenHelper(Context context) {
        //创建数据库
        super(context, "User.db", null, 1);
        // TODO Auto-generated constructor stub
        System.out.println("MyOpenHelper");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub

        //创建用户信息表
        db.execSQL("create table User(_id integer primary key autoincrement," +
                " name char(100), realname char(100), password char(32), phone char(20), personid integer(100)," +
                " sex char(10), age integer(100))");
        //String sql_user = "insert into User values (0,0,0)"; //id 自增加
        //db.execSQL(sql_user);

        //创建家庭关系表
        //db.execSQL("create table Family(_id integer primary key autoincrement, name char(10), relationship char(20)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub

    }

}