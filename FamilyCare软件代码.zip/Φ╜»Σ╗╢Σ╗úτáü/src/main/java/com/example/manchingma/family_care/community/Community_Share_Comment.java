package com.example.manchingma.family_care.community;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manchingma.family_care.R;

import java.util.Vector;

public class Community_Share_Comment extends AppCompatActivity implements View.OnClickListener{

    MyHelper myHelper;//数据库的变量
    private EditText mcomment;
    private Button msure;
    private Button mupdate;

    Vector<String> _my_comment;//记录相关信息

    private Cursor mcursor;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community__share__comment);
        myHelper =new MyHelper(this);//在这个类里面创建一个数据库实例
        init();//初始化控件

    }
    private void init() {
        mcomment = (EditText) findViewById(R.id.comment);
        msure = (Button) findViewById(R.id.sure);
        mupdate= (Button) findViewById(R.id.update);
        mcomment.setOnClickListener(this);
        msure.setOnClickListener(this);
        mupdate.setOnClickListener(this);

        mListView=(ListView)findViewById(R.id.Community_Share_Comment_lv);
        _my_comment = new Vector<>();
        //_my_phone__=new Vector<>();
    }
    @Override
    public void onClick(View v)//点击事件的对应
    {
        String comment;
        SQLiteDatabase db;//数据库
        int i=0;
        ContentValues values;
        switch (v.getId())
        {
            case R.id.sure://添加数据
                comment =mcomment.getText().toString();
                db=myHelper.getWritableDatabase();//获取可读写SQListDatabase
                values=new ContentValues();//用于存储一些数值
                values.put("comment",comment);
                db.insert("information",null,values);
                Toast.makeText(this,"评论成功",Toast.LENGTH_SHORT).show();
                db.close();
                break;
            case R.id.update://查询功能
                _my_comment.clear();//每次查询之前将数据清空，重新查询
                db=myHelper.getReadableDatabase();//获取数据库
                mcursor=db.query("information",null,null,null,null,null,null);
                mcursor.moveToFirst();//游标移回到最开始的位置
                while(mcursor.moveToNext())
                {
                    comment=mcursor.getString(0);
                    _my_comment.add(comment);
                }
                //
                //创建一个Adapter的实例
                MyBaseAdapter mAdapter_=new MyBaseAdapter();
                //设置Adapter
                mListView.setAdapter(mAdapter_);
                mcursor.close();
                db.close();

                break;
        }
    }

    //创建数据库
    class MyHelper extends SQLiteOpenHelper//创建数据库
    {
        public MyHelper(Context context)
        {
            super(context,"information.db",null,1);

        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE information(COMMENT VARCHAR(20))");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }

    }

    class MyBaseAdapter extends BaseAdapter
    {
        //得到item的总数
        @Override
        public int getCount()
        {
            //返回LIstView的item条目总数
            return _my_comment.size();

        }
        //得到item的代表对象
        @Override
        public Object getItem(int position)
        {
            return _my_comment.get(position);

        }
        //得到item的id
        @Override
        public  long getItemId(int position){
            //返回id
            return position;
        }

        @Override

        public View getView(int position, View convertView, ViewGroup parent) {

            //将 list_item的文件找出来转换为view对象
            //把设计好的列表项布局转换为view的对象
            View view=View.inflate(Community_Share_Comment.this,R.layout.comment_item,null);
            TextView m_name=(TextView)view.findViewById(R.id.my_comment);

            m_name.setText(_my_comment.get(position));
            ImageView imageView=(ImageView)view.findViewById(R.id.my_ID);
           // imageView.setBackgroundResource(R.drawable.people);//全部都设为同样的图片背景
            return  view;

        }
        //把设计好的列表项布局转换为view的对象

    }
}