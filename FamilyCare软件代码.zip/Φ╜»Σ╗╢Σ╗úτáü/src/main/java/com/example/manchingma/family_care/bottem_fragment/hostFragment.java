package com.example.manchingma.family_care.bottem_fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.manchingma.family_care.Map.mapActivity;
import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.Reminder.reminderActivity;
import com.example.manchingma.family_care.call.ContactActivity;
import com.example.manchingma.family_care.community.Community_MainActivity;


public class hostFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    public hostFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    /*
    public static hostFragment newInstance(String param1, String param2) {
        hostFragment fragment = new hostFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

  */

    //@Override
    //public void onCreate(Bundle savedInstanceState) {
    //    super.onCreate(savedInstanceState);
        //if (getArguments() != null) {
        //    mParam1 = getArguments().getString(ARG_PARAM1);
        //    mParam2 = getArguments().getString(ARG_PARAM2);
        //}
    //}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // 加载fragment的布局控件（通过layout根元素加载)

        View rootView = inflater.inflate(R.layout.fragment_host, container,
                false);
        return rootView;

        //return inflater.inflate(R.layout.fragment_host, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Button func_call=(Button)getActivity().findViewById(R.id.func_call_btn);
        func_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),ContactActivity.class);
                startActivity(intent);
            }
        });


        Button func_pos=(Button)getActivity().findViewById(R.id.func_pos_btn);
        func_pos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),mapActivity.class);
                startActivity(intent);
            }
        });


        Button func_reminder=(Button)getActivity().findViewById(R.id.func_remind_btn);
        func_reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),reminderActivity.class);
                startActivity(intent);
            }
        });

        Button func_com=(Button)getActivity().findViewById(R.id.func_com_btn);
        func_com.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),Community_MainActivity.class);
                startActivity(intent);
            }
        });

        Button func_add=(Button)getActivity().findViewById(R.id.func_add_btn);
        func_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),R.string.host_addtoast, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // TODO: Rename method, update argument and hook method into UI event


    /*
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    */
}


