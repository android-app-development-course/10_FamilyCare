package com.example.manchingma.family_care.call;


        import android.content.Intent;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.net.Uri;
        import android.os.Bundle;
        import android.support.design.widget.FloatingActionButton;
        import android.support.v7.app.AlertDialog;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.widget.ListView;
        import android.widget.SimpleAdapter;
        import android.widget.Toast;

        import com.example.manchingma.family_care.R;
        import com.example.manchingma.family_care.SQLite.MyHelper;

        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;

public class ContactActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private MyHelper helper;

    private Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        //返回按钮实现
        back = (Button) findViewById(R.id.toolbar_back_btn);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        helper=new MyHelper(getApplicationContext());

        final ListView lv=(ListView)findViewById(R.id.contact_item);
        //ListView适配器
        final SimpleAdapter adapter=new SimpleAdapter(this,
                gettingdata(),
                R.layout.contact_item,
                new String[]{"name","number"},
                new int[]{R.id.itemname,R.id.itemnumber});
        lv.setAdapter(adapter);
        //响应ListView
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String,String> map=(HashMap<String,String>)lv.getItemAtPosition(position);
                String name=map.get("name");//获取title，传到detail
                String number=map.get("number");
                if(name.equals("empty")){
                    Toast.makeText(getApplicationContext(),"联系人为空",Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent callIntent = new Intent();
                    callIntent.setAction(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse(("tel:") + number));
                    startActivity(callIntent);
                    //refresh();
                }
            }
        });
        //长按删除操作
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String,String> map=(HashMap<String,String>)parent.getItemAtPosition(position);
                final String name=map.get("name");
                final String number=map.get("number");
                AlertDialog dialog = new AlertDialog.Builder(ContactActivity.this)
                        .setTitle("提示")
                        .setMessage("确定删除？")
                        .setPositiveButton("确定", null)
                        .setNegativeButton("取消", null)
                        .show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    ///////////////没改！！！！
                    @Override
                    public void onClick(View v) {

                        SQLiteDatabase db = helper.getWritableDatabase();
                        db.execSQL("delete from Contact where name=? and number=?",
                                new String[]{name,number});
                        db.close();
                        lv.setAdapter(adapter);

                        //update
                        finish();
                        Intent intent = new Intent(ContactActivity.this, ContactActivity.class);
                        startActivity(intent);



                        /*
                        SQLiteDatabase DB = helper.getWritableDatabase();
                        //ContentValues values = new ContentValues();
                        String sql="delete from Contact where name="+name+" and number="+number+"";
                        DB.execSQL(sql);
                        //DB.delete("Contact","name=? && number=?",new String[]{name,number});
                        DB.close();
                        */

                        Toast.makeText(ContactActivity.this,"删除成功",Toast.LENGTH_SHORT).show();
                        // AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("提示").setMessage("添加成功").setPositiveButton("确定",null).show();
                    }
                });
                return false;
            }
        });


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContactDialog CD=new ContactDialog(ContactActivity.this,null);
                CD.show();
                //adapter.notifyDataSetChanged();


            }
        });
    }
    private List<Map<String,Object>> gettingdata(){
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        Map<String,Object>map=new HashMap<String, Object>();
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cursor=db.query("Contact",null,null,null,null,null,null);
        cursor.moveToFirst();
        if (cursor.getCount() == 0) {
            /*map=new HashMap<String, Object>();
            map.put("name","添加新联系人");
            list.add(map);*/
            //ImageView IV=(ImageView)findViewById(R.id.image);
            //IV.setImageBitmap(R.mipmap.ic_add);
            //IV.setBackgroundResource(R.mipmap.ic_add);
        }
        else {
            //cursor.moveToFirst();
            map = new HashMap<String, Object>();
            //map.put("title", cursor.getString(1));
            map.put("name", cursor.getString(cursor.getColumnIndex("name")));
            map.put("number", cursor.getString(cursor.getColumnIndex("number")));
            list.add(map);
            while (cursor.moveToNext()) {
                map = new HashMap<String, Object>();
                map.put("name", cursor.getString(cursor.getColumnIndex("name")));
                map.put("number", cursor.getString(cursor.getColumnIndex("number")));
                list.add(map);
            }
            cursor.close();
            db.close();
        }
        return list;
    }

}
