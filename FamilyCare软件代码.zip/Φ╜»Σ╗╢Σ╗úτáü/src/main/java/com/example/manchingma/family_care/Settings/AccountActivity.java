package com.example.manchingma.family_care.Settings;


        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.Menu;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.ListView;
        import android.widget.SimpleAdapter;

        import com.example.manchingma.family_care.R;

        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;

public class AccountActivity extends AppCompatActivity {

    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        //绑定ListView
        ListView my_info=(ListView)findViewById(R.id.account_item);
        SimpleAdapter mSchedule=new SimpleAdapter(this,
                getMyInfoData(),//数据来源//
                R.layout.account_item,//XML实现
                new String[]{"ItemTile","ItemText"},//数组与ListView对应的子项
                //my_info_item.XML文件里面的两个TextView ID
                new int[]{R.id.ItemTitle,R.id.ItemText} );
        my_info.setAdapter(mSchedule);

        back=(Button)findViewById(R.id.toolbar_back_btn);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        //my_info.setAdapter(adapter);
    }
    private List<Map<String,Object>> getMyInfoData(){
        List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
        Map<String,Object>map=new HashMap<String,Object>();
        map.put("ItemTitle","User Name");
        map.put("ItemText","User Name");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","Real Name");
        map.put("ItemText","Real Name");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","Gender");
        map.put("ItemText","Gender");
        list.add(map);

        map=new HashMap<String,Object>();
        map.put("ItemTitle","Phone Number");
        map.put("ItemText","Phone Number");
        list.add(map);

        return list;
    }

}

