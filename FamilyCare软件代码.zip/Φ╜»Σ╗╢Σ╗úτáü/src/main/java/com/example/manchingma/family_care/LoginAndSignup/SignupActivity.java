package com.example.manchingma.family_care.LoginAndSignup;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.SQLite.MyOpenHelper;
import com.example.manchingma.family_care.SQLite.User;
import android.view.View.OnFocusChangeListener;
import java.util.ArrayList;
import java.util.List;

public class SignupActivity extends AppCompatActivity {

    private Button signup;
    private Button choosepic;
    private EditText name;
    private EditText realname;
    private EditText password;
    private EditText psid;
    private EditText phone;
    private EditText age;
    private RadioGroup sex;
    private RadioButton female;
    private RadioButton male;
    private RadioButton rb;

    //private QuickContactBadge userpic;

    //数据库变量
    List<User> UserList;
    private MyOpenHelper myOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        //StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_signup);

        signup = (Button) findViewById(R.id.signup_btn);
        name = (EditText) findViewById(R.id.signup_name);
        realname = (EditText) findViewById(R.id.signup_realname);
        password = (EditText) findViewById(R.id.signup_password);
        phone = (EditText) findViewById(R.id.signup_number);
        psid = (EditText) findViewById(R.id.signup_pcid);
        age=(EditText)findViewById(R.id.signup_age);
        choosepic=(Button)findViewById(R.id.signup_pic);

        male=(RadioButton)findViewById(R.id.signup_sex_male);
        female=(RadioButton)findViewById(R.id.signup_sex_female);

        //实例化
        UserList = new ArrayList<User>();
        myOpenHelper=new MyOpenHelper(this);


        //RadioGroup
        sex = (RadioGroup)this.findViewById(R.id.radioGroup);
        //绑定一个匿名监听器
        /*
        sex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup arg0, int arg1) {
                // TODO Auto-generated method stub
                // 获取变更后的选中项的ID
                int radioButtonId = arg0.getCheckedRadioButtonId();

                //根据ID获取RadioButton的实例
                rb = (RadioButton)findViewById(radioButtonId);
            }
        });
        */

        name.setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                // TODO Auto-generated method stub
                if (!hasFocus) {
                    if (name.getText().toString().trim().length() < 4) {
                        Toast.makeText(SignupActivity.this, R.string.toast_username, Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

        password.setOnFocusChangeListener(new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                // TODO Auto-generated method stub
                if (!hasFocus) {
                    if (password.getText().toString().trim().length() < 6) {
                        Toast.makeText(SignupActivity.this, R.string.toast_pswless, Toast.LENGTH_SHORT).show();
                    }
                    else if (password.getText().toString().trim().length() > 32) {
                        Toast.makeText(SignupActivity.this, R.string.toast_pswmore, Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });


        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(!checkEdit()){
                    return;
                }

                String newname=name.getText().toString().trim();
                String newrealname=realname.getText().toString().trim();
                String newpassword=password.getText().toString().trim();
                String newphone=phone.getText().toString().trim();
                String newpersonid=psid.getText().toString().trim();
                String newage=age.getText().toString().trim();
                String newsex=null;
                        //rb.getText().toString();

                if (!CheckIsDataAlreadyInDBorNot(newname))
                {
                    register(newname,newrealname,newpassword,newphone,newpersonid,newsex,newage);
                    Toast.makeText(SignupActivity.this, R.string.toast_signupsuccess, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(SignupActivity.this, R.string.toast_alreadyin, Toast.LENGTH_SHORT).show();
                }


                // TODO Auto-generated method stub
                /*
                String httpUrl= "https://192.168.1.100:8080/web-test/register.jsp";
                //"http://192.168.1.101:8080/SHproject/homepage/register";

                HttpPost httpRequest=new HttpPost(httpUrl);
                List<NameValuePair> params=new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("username",name.getText().toString().trim()));
                params.add(new BasicNameValuePair("password",password.getText().toString().trim()));
                HttpEntity httpentity = null;
                try {
                    httpentity = new UrlEncodedFormEntity(params,"utf8");
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                httpRequest.setEntity(httpentity);
                HttpClient httpclient=new DefaultHttpClient();
                HttpResponse httpResponse = null;
                try {
                    httpResponse = httpclient.execute(httpRequest);
                } catch (ClientProtocolException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if(httpResponse.getStatusLine().getStatusCode()==200)
                {
                    String strResult = null;
                    try {
                        strResult = EntityUtils.toString(httpResponse.getEntity());
                    } catch (ParseException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    Toast.makeText(SignupActivity.this, strResult, Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(SignupActivity.this, "请求错误", Toast.LENGTH_SHORT).show();
                }
                */
            }
        });
    }

    private boolean checkEdit() {
        if (name.getText().toString().trim() == null || name.getText().toString().trim().equals("")
                ||realname.getText().toString().trim() == null || realname.getText().toString().trim().equals("")
                || password.getText().toString().trim() == null || password.getText().toString().trim().equals("")
                || psid.getText().toString().trim() == null || psid.getText().toString().trim().equals("")
                || phone.getText().toString().trim() == null || phone.getText().toString().trim().equals("")) {
            Toast.makeText(SignupActivity.this, R.string.toast_signupnotnull, Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (name.getText().toString().trim() != null && !(name.getText().toString().trim().equals(""))
                &&realname.getText().toString().trim() != null && !(realname.getText().toString().trim().equals(""))
                && password.getText().toString().trim() != null && !(password.getText().toString().trim().equals(""))
                && phone.getText().toString().trim() != null && !(phone.getText().toString().trim().equals(""))
                && psid.getText().toString().trim() != null && !(psid.getText().toString().trim().equals(""))
                )
            return true;
        return false;
    }

    //检验用户名是否已存在
    public boolean CheckIsDataAlreadyInDBorNot(String value){
        SQLiteDatabase db=myOpenHelper.getWritableDatabase();
        String Query = "Select * from User where name =?";
        Cursor cursor = db.rawQuery(Query,new String[] { value });
        if (cursor.getCount()>0){
            cursor.close();
            return  true;
        }
        cursor.close();
        return false;
    }

    //向数据库插入数据
    public boolean register(String username,
                            String realname,
                            String password,
                            String phone,
                            String personid,
                            String sex,
                            String age){
        SQLiteDatabase db= myOpenHelper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("name",username);
        values.put("realname",realname);
        values.put("password",password);
        values.put("phone",phone);
        values.put("personid",personid);
        values.put("sex",sex);
        values.put("age",age);

        db.insert("User",null,values);
        db.close();
        return true;
    }
}

