package com.example.manchingma.family_care.SQLite;

import android.database.sqlite.SQLiteDatabase;
import android.hardware.camera2.params.StreamConfigurationMap;

/**
 * Created by manchingma on 2018/1/5.
 */

public class User {
    private String _id;
    private String name;
    private String realname;
    private String password;
    private String phone;
    private String personid;
    private String sex;
    private String age;


    public String get_id() {
        return _id;
    }
    public void set_id(String _id) {
        this._id = _id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getRealname() {
        return realname;
    }
    public void setRealname(String realname) {
        this.realname = realname;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getPersonid() {
        return personid;
    }
    public void setPersonid(String personid) {
        this.personid =personid;
    }
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getAge() {
        return age;
    }
    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return name + ", " + realname + ", " +password + ", " +phone + ", " + personid + ", " + sex  + ", " + age;
    }

    public User(String _id,
                String name,
                String realname,
                String password,
                String phone,
                String personid,
                String sex,
                String age) {
        super();
        this._id = _id;
        this.name = name;
        this.realname=realname;
        this.password=password;
        this.phone = phone;
        this.personid = personid;
        this.sex=sex;
        this.age=age;
    }


}