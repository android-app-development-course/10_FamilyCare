package com.example.manchingma.family_care.LoginAndSignup;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

//实现自动登录和记住密码
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;


import com.example.manchingma.family_care.MainActivity;
import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.SQLite.MyOpenHelper;

public class LoginActivity extends AppCompatActivity {

    private Button login;
    private Button signup;
    private Button forgetpassword;

    private EditText name;
    private EditText password;

    private CheckBox autologin;//自动登录勾选项
    private CheckBox rememberpsw;

    //数据库使用的相关变量
    private MyOpenHelper myOpenHelper;

    //实现CheckBox所需要的变量
    SharedPreferences sp = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sp = this.getSharedPreferences("MyInfo", Context.MODE_PRIVATE);

        //三个button
        login=(Button)findViewById(R.id.login);
        signup=(Button)findViewById(R.id.login_signup);
        forgetpassword=(Button)findViewById(R.id.login_forgetpsw);

        //用户登录信息填写
        name=(EditText)findViewById(R.id.login_account);
        password=(EditText)findViewById(R.id.login_password);

        // 创建MyOpenHelper实例
        myOpenHelper = new MyOpenHelper(this);

        //Checkbox初始化
        autologin=(CheckBox)findViewById(R.id.auto);
        rememberpsw=(CheckBox)findViewById(R.id.remember);

        if (sp.getBoolean("checkboxBoolean", false))
        {
            name.setText(sp.getString("name", null));
            password.setText(sp.getString("password", null));

            autologin.setChecked(true);//默认为自动登录的状态
            rememberpsw.setChecked(true);//默认为记住密码的状态

        }

        //登录
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (rememberpsw.isChecked())
                {
                    Editor editor = sp.edit();
                    editor.putString("name", name.getText().toString());
                    editor.putString("password", password.getText().toString());
                    editor.putBoolean("checkboxBoolean", true);
                    editor.commit();
                }
                else
                {
                    Editor editor = sp.edit();
                    editor.putString("name", null);
                    editor.putString("password", null);
                    editor.putBoolean("checkboxBoolean", false);
                    editor.commit();
                }

                if (name.getText().toString().trim() == null || name.getText().toString().trim().equals("")
                        || password.getText().toString().trim() == null || password.getText().toString().trim().equals("")) {
                    Toast.makeText(LoginActivity.this, R.string.tosat_loginnotnull, Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (name.getText().toString().trim() != null && !(name.getText().toString().trim().equals(""))
                        && password.getText().toString().trim() != null && !(password.getText().toString().trim().equals(""))
                        && login(name.getText().toString(),password.getText().toString()))
                {
                    //Intent跳转
                    Toast.makeText(LoginActivity.this, R.string.toast_loginsuccess, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else if(login(name.getText().toString(),password.getText().toString())==false){
                    Toast.makeText(LoginActivity.this, R.string.toast_usernoexist, Toast.LENGTH_SHORT).show();
                }
            }
        });

        //点击注册按钮进入注册页面
        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        //点击忘记密码进入密码重置页面
        forgetpassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //在按钮响应函数中添加如下两句话就ok了
                Intent intent = new Intent(LoginActivity.this, forgetpswActivity.class);
                startActivity(intent);
            }
        });
    }

    //验证登录（是否存在用户）
    public boolean login(String username,String password) {
        SQLiteDatabase db = myOpenHelper.getWritableDatabase();
        String sql = "select * from User where name=? and password=?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        }
        return false;
    }
}
