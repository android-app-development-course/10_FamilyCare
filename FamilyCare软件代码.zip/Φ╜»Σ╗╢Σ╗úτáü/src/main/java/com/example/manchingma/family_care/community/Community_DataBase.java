package com.example.manchingma.family_care.community;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Administrator on 2018/1/3.
 */

public class Community_DataBase extends SQLiteOpenHelper {
    //上下文对象、数据库名称、游标工厂（通常是null）、数据库版本
    public Community_DataBase(Context context) {
        super(context, "communityshare", null, 1);
    }

    @Override
    //数据库第一次被创建时调用该方法
    public void onCreate(SQLiteDatabase db) {
   //     db.execSQL("CREATE TABLE information(COMMENT VARCHAR(20))");
        //创建表
        db.execSQL("CREATE TABLE communityshare(_User_Id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "content TEXT," +
                "communityimage1 BLOB," +
                "communityimage2 BLOB)"
        );//用户的ID,文字，还有两张图片

    }
    @Override
    //在数据库版本号增加时调用
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
