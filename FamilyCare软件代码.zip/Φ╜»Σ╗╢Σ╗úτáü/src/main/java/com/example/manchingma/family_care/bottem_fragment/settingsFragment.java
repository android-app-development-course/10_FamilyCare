package com.example.manchingma.family_care.bottem_fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.Button;

import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.Settings.AboutActivity;
import com.example.manchingma.family_care.Settings.AccountActivity;
import com.example.manchingma.family_care.Settings.AddressActivity;
import com.example.manchingma.family_care.Settings.FamilyActivity;
import com.example.manchingma.family_care.Settings.SystemActivity;

public class settingsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    public settingsFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    /*
    public static settingsFragment newInstance(String param1, String param2) {
        settingsFragment fragment = new settingsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
*/
    //@Override
    //public void onCreate(Bundle savedInstanceState) {
        //super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_account);
        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            Button my_setting_account=(Button)getActivity().findViewById(R.id.btn_mysetting_account);
            Button my_setting_family=(Button)getActivity().findViewById(R.id.btn_mysetting_family);
            Button my_setting_homeAddress=(Button)getActivity().findViewById(R.id.btn_mysetting_homeAddress);
            Button my_setting_setting=(Button)getActivity().findViewById(R.id.btn_mysetting_setting);
            Button my_setting_about=(Button)getActivity().findViewById(R.id.btn_mysetting_help);

            my_setting_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_accont=new Intent(getActivity(),AccountActivity.class);
                //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                startActivity(intent_accont);
            }
        });
            my_setting_family.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent_family=new Intent(getActivity(),FamilyActivity.class);
                    startActivity(intent_family);
                }
            });
            my_setting_homeAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent_adress=new Intent(getActivity(),AddressActivity.class);
                    //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                    startActivity(intent_adress);
                }
            });

            my_setting_setting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent_setting=new Intent(getActivity(),SystemActivity.class);
                    //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                    startActivity(intent_setting);
                }
            });
            my_setting_about.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent_about=new Intent(getActivity(),AboutActivity.class);
                    //  intent_setting_accont.setAction(MysettingActivity.this,MyInfoActivity.class);
                    startActivity(intent_about);
                }
            });
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_settings, container,
                false);

        return rootView;

    }

    /*
    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    */
}
