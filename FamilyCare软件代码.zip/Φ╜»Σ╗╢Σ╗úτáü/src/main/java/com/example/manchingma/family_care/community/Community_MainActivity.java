package com.example.manchingma.family_care.community;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manchingma.family_care.R;

import java.util.ArrayList;
import java.util.List;

public class Community_MainActivity extends AppCompatActivity implements View.OnClickListener{

   // Community_DataBase myHelper;//数据库的变量
    private Button mCamera;
   // Vector<String> _my_photo;//记录相关信息
   // private Cursor mcursor;
    private ListView mListView;
    
    private MyBaseAdapter mAdapter;
    Community_DataBase mcommunity_DataBase;

    //从数据库读出来的数据
    List<String> Community_Share_ContentList;

    List<Drawable> community_image1;
    List<Drawable>community_image2;

    //当前用户
    // Community_User user;
    //需要适配的数据
    private String[] names = {"1", "12", "李11", "黄11"};

    //需要适配的头像图片
    private int[] head_photo = {R.drawable.ph_1, R.drawable.ph_2, R.drawable.ph_3, R.drawable.ph_4};

    //需要适配的语句
    private String[] content = {"很棒", "今日事件", "感觉不错的", "hhhh耶！"};

    //需要适配的照片1
    private int[] photo_1 = {R.drawable.ph_1, R.drawable.ph_2, R.drawable.ph_3, R.drawable.ph_4};

    //需要适配的照片2
    private int[] photo_2 = {R.drawable.ph_2, R.drawable.ph_1, R.drawable.ph_4, R.drawable.ph_3};
    private Button releaseCommunity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //去除工具栏
        getSupportActionBar().hide();
        setContentView(R.layout.activity_community__main);
        mcommunity_DataBase=new Community_DataBase(this);//在这个类里面创建一个数据库实例
        init();//初始化控件
    }
    private void init() {
        mCamera = (Button) findViewById(R.id.camera);
        mCamera.setOnClickListener(this);

        mListView=(ListView)findViewById(R.id.Community_Share_lv);
      //  _my_photo= new Vector<>();
        Community_Share_ContentList = new ArrayList<String>();
       // user = new Community_User();

        community_image1=new ArrayList<Drawable>();
        community_image2=new ArrayList<Drawable>();
        //实例化数据库对象并读取数据库的信息
        //  mcommunity_DataBase = new Community_DataBase(Community_MainActivity.this);
        ReadData();

        //创建一个Adapter的实例
        mAdapter = new MyBaseAdapter();
        //设置Adapter
        mListView.setAdapter(mAdapter);
    }
    @Override
    protected void onRestart(){
        super.onRestart();
        Refresh();
    }

    //刷新列表
    void Refresh(){
        ReadData();
        mAdapter.notifyDataSetChanged();
    }
    //从数据库读取内容
    void ReadData(){
        //获得可以读取数据的SQLiteDataBase对象
        SQLiteDatabase db = mcommunity_DataBase.getReadableDatabase();
        //游标　
        Cursor cursor = db.query("communityshare",null,
                null,null,null,
                null,null);
       cursor.moveToFirst();//游标移回到最开始的位置

        if(cursor.getCount() == 0){
           Toast.makeText(Community_MainActivity.this,"暂无数据",Toast.LENGTH_SHORT).show();
        }
        else{
            try{
                //先清除数据
                Community_Share_ContentList.clear();
                community_image1.clear();
                community_image2.clear();
                //将数据库的信息添加到列表中
                cursor.moveToLast();
                int position = cursor.getPosition();
                byte[] bmpout;
                Bitmap bitmap;
                BitmapDrawable bitmapDrawable;
                Drawable drawable;

                while(position >= 0){
                    position --;
                    Community_Share_ContentList.add(cursor.getString(cursor.getColumnIndex("content")));
                    //获取数据
                    bmpout = cursor.getBlob(cursor.getColumnIndex("communityimage1"));
                    //将获取的数据转换成drawable
                    bitmap = BitmapFactory.decodeByteArray(bmpout, 0, bmpout.length, null);
                    bitmapDrawable = new BitmapDrawable(bitmap);
                    drawable = bitmapDrawable;
                    community_image1.add(drawable);
                    //获取数据
                    bmpout = cursor.getBlob(cursor.getColumnIndex("communityimage2"));
                    //将获取的数据转换成drawable
                    bitmap = BitmapFactory.decodeByteArray(bmpout, 0, bmpout.length, null);
                    bitmapDrawable = new BitmapDrawable(bitmap);
                    drawable = bitmapDrawable;
                    community_image2.add(drawable);
                    cursor.moveToPosition(position);
                }
            }
            //空指针异常
            catch (NullPointerException e){
            }
        }//end else
        //关闭游标和数据库
        cursor.close();
        db.close();
    }

    class MyBaseAdapter extends BaseAdapter {

        //得到item的总数
        @Override
        public int getCount() {
            //返回ListView Item条目的总数
            return names.length +  Community_Share_ContentList.size();
        }

        //得到item代表的对象
        @Override
        public Object getItem(int position) {
            return names[position];
        }

        //得到item的id
        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            //将list_item.xml文件找出来并转换成vi对象
            View view = View.inflate(Community_MainActivity.this, R.layout.share_list, null);

            if(position <  Community_Share_ContentList.size())
            {
                //为用户加名字
               TextView tv_name = (TextView) view.findViewById(R.id.share_tv_name);
                //tv_name.setText(user.getUserName());
                //为用户加头像
                ImageView imageView = (ImageView) view.findViewById(R.id._item_image);
                imageView.setBackgroundResource(R.drawable.ph_1);
                //加内容
                TextView tv_content = (TextView) view.findViewById(R.id.share_tv_content);
                tv_content.setText( Community_Share_ContentList.get(position));
                //加照片1
                ImageView imageView1 = (ImageView) view.findViewById(R.id.share_iv_photo1);
                imageView1.setImageDrawable(community_image1.get(position));
                //加照片2
                ImageView imageView2 = (ImageView) view.findViewById(R.id.share_iv_photo2);
                imageView2.setImageDrawable(community_image2.get(position));
            }
            else{
                //加名字
                TextView tv_name = (TextView) view.findViewById(R.id.share_tv_name);
                tv_name.setText(names[position- Community_Share_ContentList.size()]);
                //加头像
                ImageView imageView = (ImageView) view.findViewById(R.id._item_image);
                imageView.setBackgroundResource(head_photo[position-Community_Share_ContentList.size()]);
                //加内容
                TextView tv_content = (TextView) view.findViewById(R.id.share_tv_content);
                tv_content.setText(content[position-Community_Share_ContentList.size()]);
                //加照片1
                ImageView imageView1 = (ImageView) view.findViewById(R.id.share_iv_photo1);
                imageView1.setBackgroundResource(photo_1[position-Community_Share_ContentList.size()]);
                //加照片2
                ImageView imageView2 = (ImageView) view.findViewById(R.id.share_iv_photo2);
                imageView2.setBackgroundResource(photo_2[position-Community_Share_ContentList.size()]);
            }

            //点赞
            final Button fish = (Button) view.findViewById(R.id.btn_good);
            fish.setOnClickListener(new View.OnClickListener() {
                boolean flag = false;
                @Override
                public void onClick(View view) {
                    flag = !flag;
                    if(flag)//如果点击了
                        fish.setBackgroundResource(R.drawable.ic_good_red);
                    else fish.setBackgroundResource(R.drawable.ic_good);
                }
            });

            //评论
            final Button Comment = (Button) view.findViewById(R.id.btn_comment);
            Comment.setOnClickListener(new View.OnClickListener() {
                boolean flag1 = false;
                @Override
                public void onClick(View view) {
                    flag1 = !flag1;
                    if(flag1)//如果点击了
                    {
                        Intent intent_Comment=new Intent(Community_MainActivity.this,Community_Share_Comment.class);
                        startActivity(intent_Comment);
                    }
                    else Comment.setBackgroundResource(R.drawable.ic_comment);
                }
            });
/*
            //点击分享到其他平台
            Button share = (Button)view.findViewById(R.id.btn_share);
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //分享
                    shareUtil.shareLink(getString(R.string.github_url),
                            getString(R.string.share_title), Community_Share_Activity.this);

                }
            });

*/
            return view;
        }
    }
    @Override
    public void onClick(View v)//点击事件的对应
    {
        switch (v.getId()) {
            case R.id.camera://添加数据
                Intent intent=new Intent(Community_MainActivity.this,Community_Share_Release.class);
                startActivity(intent);
               break;
        }
    }
}
