package com.example.manchingma.family_care.call;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.SQLite.MyHelper;

public class ContactDialog extends Dialog {
    private String dialogName;
    private EditText name;
    private EditText number;
    private Button  OK;
    private Button Cancel;
    SQLiteDatabase DB;
    MyHelper helper;
    public ContactDialog(Context context,String dialogName){
        super(context);
        this.dialogName=dialogName;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.contact_dialog_layout);
        name=(EditText)findViewById(R.id.edit_name);
        number=(EditText)findViewById(R.id.edit_number);
        OK=(Button)findViewById(R.id.btn_ok);
        Cancel=(Button)findViewById(R.id.cancel);
        helper=new MyHelper(getContext());
        OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase DB=helper.getWritableDatabase();
                ContentValues values=new ContentValues();
                values.put("name",name.getText().toString());
                values.put("number",number.getText().toString());
                DB.insert("Contact",null,values);
                DB.close();
                AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("提示").setMessage("添加成功").setPositiveButton("确定",null).show();
                dismiss();
            }
        });
        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }
}

