package com.example.manchingma.family_care.LoginAndSignup;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manchingma.family_care.R;
import com.example.manchingma.family_care.SQLite.MyOpenHelper;

public class forgetpswActivity extends AppCompatActivity {

    private EditText et_phone;
    private EditText et_newpsw;
    private Button submit;

    MyOpenHelper myOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpsw);

        et_phone=(EditText)findViewById(R.id.et_phone);
        et_newpsw=(EditText)findViewById(R.id.et_new);
        submit=(Button)findViewById(R.id.newsubmit);

        // 创建MyOpenHelper实例
        myOpenHelper = new MyOpenHelper(this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (et_phone.getText().toString().trim()==null||et_phone.getText().toString().trim().equals("")
                        ||et_newpsw.getText().toString().trim()==null||et_newpsw.getText().toString().trim().equals("")){
                    Toast.makeText(forgetpswActivity.this, R.string.toast_notnull, Toast.LENGTH_SHORT).show();
                }
                else if ((et_phone.getText().toString().trim()!=null)&&!(et_phone.getText().toString().trim().equals(""))
                        &&(et_newpsw.getText().toString().trim()!=null)&&!(et_newpsw.getText().toString().trim().equals(""))
                        && forget(et_phone.getText().toString())
                        ){
                    dbUpdatePassword(et_phone.getText().toString(),et_newpsw.getText().toString());
                    Toast.makeText(forgetpswActivity.this, R.string.toast_update, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(forgetpswActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else if ((et_phone.getText().toString().trim()!=null)&&!(et_phone.getText().toString().trim().equals(""))
                        &&(et_newpsw.getText().toString().trim()!=null)&&!(et_newpsw.getText().toString().trim().equals(""))
                        && !forget(et_phone.getText().toString())
                        ){
                    Toast.makeText(forgetpswActivity.this, R.string.toast_incorrect, Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    //验证是否存在用户

    public boolean forget(String phone) {
        SQLiteDatabase db = myOpenHelper.getReadableDatabase();
        String sql = "select * from User where phone=?";
        Cursor cursor=db.query("User",null,"phone=?",new String[]{phone+""},null,null,null);
        boolean result=cursor.moveToNext();
        cursor.close();
        db.close();
        return result;
    }

    public void dbUpdatePassword(String phone, String newPassword) {
        SQLiteDatabase db = myOpenHelper.getWritableDatabase();
        db.execSQL("update User set password=? where phone=?",
                new String[]{newPassword,phone});
        db.close();

        /*
        ContentValues values = new ContentValues();
        values.put("password", newPassword);
        //得到可写的SQLiteDatabase对象
        SQLiteDatabase db = myOpenHelper.getWritableDatabase();
        //调用insert方法，将数据插入数据库
        //参数3：where 子句 "?"是占位符号，对应后面的"1",这和web开发时的语法是一样的
        db.update("User", values, "phone=?", new String[]{phone});
        */
    }
}
